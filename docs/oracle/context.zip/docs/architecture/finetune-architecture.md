# FineTune Architecture

## High-Level Component Diagram

```mermaid
flowchart TB
  subgraph AppEntry["App Entry (AppKit Lifecycle)"]
    FineTuneApp["FineTuneApp.swift\n(@main + AppDelegate)"]
    MenuBarStatusController["MenuBarStatusController\n(NSStatusItem + KeyablePanel)"]
  end

  subgraph ViewModel["ViewModel"]
    MenuBarPopupViewModel["MenuBarPopupViewModel\n(@Observable @MainActor)\nEQ expansion, animation,\ndevice sorting, app activation"]
  end

  subgraph UI["UI (SwiftUI)"]
    MenuBarPopupView["MenuBarPopupView\n(@Bindable viewModel)"]

    subgraph Rows["Row Views"]
      DeviceRow["DeviceRow"]
      AppRowWithLevelPolling["AppRowWithLevelPolling\n(timer-based VU polling)"]
      AppRow["AppRow"]
      AppRowEQToggle["AppRowEQToggle\n(animated slider↔X)"]
    end

    subgraph Components["Shared Components"]
      DevicePicker["DevicePicker"]
      DeviceIconView["DeviceIconView\n(NSImage + SF Symbol fallback)"]
      EQPanelView["EQPanelView"]
      EQSliderView["EQSliderView"]
      VUMeter["VUMeter\n(8-bar level meter)"]
      LiquidGlassSlider["LiquidGlassSlider"]
      MuteButton["MuteButton"]
      SliderAutoUnmute["SliderAutoUnmute\n(ViewModifier)"]
      DropdownMenu["DropdownMenu"]
    end

    subgraph DesignSystem["Design System"]
      DesignTokens["DesignTokens\n(colors, typography, spacing,\ndimensions, animations)"]
    end
  end

  subgraph State["State & Orchestration"]
    AudioEngine["AudioEngine\n(@Observable @MainActor)\nPermission confirmation,\ncoreaudiod restart handler,\ntap health checks (3s)"]
    DeviceVolumeMonitor["DeviceVolumeMonitor\n(@Observable @MainActor)\nDebounced listeners,\nvolume/mute/default tracking"]
    VolumeState["VolumeState\n(per-app & per-device persistence)"]
    SettingsManager["SettingsManager\n(UserDefaults)"]
  end

  subgraph Monitors["Monitors"]
    AudioProcessMonitor["AudioProcessMonitor\n(running audio apps)"]
    AudioDeviceMonitor["AudioDeviceMonitor\n(output devices + icons,\ncoreaudiod restart callback)"]
  end

  subgraph Routing["Audio Routing (Real-Time)"]
    ProcessTapController["ProcessTapController\n(per-app audio tap,\ncrossfade state machine,\nlock-free atomic state)"]
    TapResources["TapResources\n(CoreAudio object lifecycle)"]
    TapDiagnostics["TapDiagnostics\n(19-field RT-safe snapshot)"]
    EQProcessor["EQProcessor\n(10-band biquad EQ)"]
    AudioFormatConverter["AudioFormatConverter"]
    CrossfadeState["CrossfadeState\n(lock-free state machine)"]
  end

  subgraph DSP["Audio Processing"]
    AudioBufferProcessor["AudioBufferProcessor"]
    GainProcessor["GainProcessor"]
    VolumeRamper["VolumeRamper"]
    SoftLimiter["SoftLimiter"]
    BiquadMath["BiquadMath"]
  end

  subgraph Models["Models"]
    AudioApp["AudioApp"]
    AudioDevice["AudioDevice"]
    EQSettings["EQSettings\n(10 bands, ±12dB)"]
    EQPreset["EQPreset"]
    VolumeMapping["VolumeMapping\n(linear gain ↔ log slider)"]
  end

  subgraph CoreAudioTypes["CoreAudio Utilities"]
    CoreAudioQueues["CoreAudioQueues\n(shared listener queue)"]
    AudioScope["AudioScope"]
    TransportType["TransportType"]
    TapFormat["TapFormat"]
    Extensions["AudioDeviceID + AudioObjectID\nextensions (9 files)"]
  end

  subgraph CoreAudio["macOS Audio Services"]
    CoreAudioHAL["CoreAudio HAL"]
    AudioToolbox["AudioToolbox"]
    DefaultOutput["Default Output Device"]
    OutputDevices["Output Devices"]
  end

  subgraph Persistence["Persistence"]
    SettingsFiles["Settings/*.json"]
  end

  subgraph Utilities["Utilities"]
    DeviceIconCache["DeviceIconCache"]
    SingleInstanceGuard["SingleInstanceGuard"]
  end

  %% App Entry Flow
  FineTuneApp -->|applicationDidFinishLaunching| MenuBarStatusController
  FineTuneApp -->|creates| AudioEngine
  MenuBarStatusController -->|creates| MenuBarPopupViewModel
  MenuBarStatusController -->|hosts in KeyablePanel| MenuBarPopupView

  %% ViewModel Bindings
  MenuBarPopupViewModel --> AudioEngine
  MenuBarPopupViewModel --> DeviceVolumeMonitor
  MenuBarPopupView -->|"@Bindable viewModel"| MenuBarPopupViewModel

  %% UI → State
  AppRow -->|volume/mute/device| AudioEngine
  DeviceRow -->|volume/mute/default| DeviceVolumeMonitor
  DevicePicker -->|select device| AudioEngine
  EQPanelView -->|EQ settings| AudioEngine
  VUMeter -->|polls levels| AudioEngine
  AppRowEQToggle -->|toggleEQ| MenuBarPopupViewModel

  %% UI Composition
  MenuBarPopupView --> DeviceRow
  MenuBarPopupView --> AppRowWithLevelPolling
  AppRowWithLevelPolling --> AppRow
  AppRow --> AppRowEQToggle
  AppRow --> MuteButton
  AppRow --> LiquidGlassSlider
  AppRow --> VUMeter
  AppRow --> DevicePicker
  AppRow --> EQPanelView
  DeviceRow --> DeviceIconView
  DevicePicker --> DeviceIconView
  AppRow -.->|uses| SliderAutoUnmute
  DeviceRow -.->|uses| SliderAutoUnmute

  %% AudioEngine → Subsystems
  AudioEngine --> AudioProcessMonitor
  AudioEngine --> AudioDeviceMonitor
  AudioEngine --> DeviceVolumeMonitor
  AudioEngine --> VolumeState
  AudioEngine --> SettingsManager
  AudioEngine -->|"create per-app taps\n(1 per audio process)"| ProcessTapController

  %% Monitors → CoreAudio
  AudioProcessMonitor -->|process list| CoreAudioHAL
  AudioDeviceMonitor -->|"device list\n+ service restart"| CoreAudioHAL
  DeviceVolumeMonitor -->|default/volume/mute| AudioToolbox
  DeviceVolumeMonitor -->|default device UID| CoreAudioHAL
  DeviceVolumeMonitor --> DefaultOutput
  DefaultOutput --> OutputDevices

  %% Audio Routing → CoreAudio
  ProcessTapController -->|process tap| CoreAudioHAL
  ProcessTapController -->|aggregate devices| CoreAudioHAL
  ProcessTapController --> TapResources
  ProcessTapController --> TapDiagnostics
  ProcessTapController --> EQProcessor
  ProcessTapController --> AudioFormatConverter
  ProcessTapController --> CrossfadeState
  ProcessTapController --> OutputDevices

  %% DSP
  EQProcessor --> BiquadMath
  ProcessTapController --> GainProcessor
  ProcessTapController --> VolumeRamper
  ProcessTapController --> SoftLimiter

  %% CoreAudio Utilities
  AudioDeviceMonitor --> Extensions
  DeviceVolumeMonitor --> CoreAudioQueues
  AudioProcessMonitor --> CoreAudioQueues
  Extensions --> CoreAudioHAL

  %% Persistence
  SettingsManager --> SettingsFiles
  VolumeState --> SettingsFiles

  CoreAudioHAL --- AudioToolbox
```

## Data Flow Summary

```
User interaction → SwiftUI Views → MenuBarPopupViewModel / AudioEngine
                                          ↓
                                   ProcessTapController (1 per app)
                                          ↓
                            CoreAudio HAL (process tap + aggregate device)
                                          ↓
                               Real-time audio callback
                                          ↓
                    AudioFormatConverter → GainProcessor → EQProcessor → SoftLimiter
                                          ↓
                                    Output Device
```

## Key Architectural Patterns

### App Lifecycle (AppKit, not SwiftUI Scene)
`FineTuneApp` uses `@NSApplicationDelegateAdaptor(AppDelegate)`. The `AppDelegate` creates `AudioEngine` and `MenuBarStatusController` in `applicationDidFinishLaunching`. `MenuBarStatusController` owns an `NSStatusItem` with a `KeyablePanel` (non-activating panel that can become key). Left-click toggles the popup; right-click shows a context menu. FluidMenuBarExtra was removed due to macOS 26 breakage.

### ViewModel Layer
`MenuBarPopupViewModel` (`@Observable @MainActor`) owns EQ expansion state (`expandedEQAppID`), animation debounce, popup visibility tracking (pauses VU polling when hidden), device sorting logic, and app activation (via AppleScript). `MenuBarPopupView` binds to it via `@Bindable`.

### Per-App Audio Taps
`AudioEngine` maintains a `[pid_t: ProcessTapController]` dictionary — one tap per audio-producing process. Each `ProcessTapController` manages its own CoreAudio process tap, aggregate device, format converter, and crossfade state machine for seamless device switching.

### Permission Confirmation
On first launch, taps start with `.unmuted` (safe if app dies during permission grant). Once real input audio is detected (`inputHasData > 0` or `lastInputPeak > 0.0001`), taps are upgraded to `.mutedWhenTapped` via `recreateAllTaps()`. This prevents the audio-mute-on-permission-grant bug.

### Crossfade Device Switching
`CrossfadeState` implements a lock-free state machine for glitch-free device switching. Primary and secondary taps overlap during transition, with equal-power crossfade. Bluetooth devices get longer warmup (500ms vs 50ms standard).

### Real-Time Safety
`ProcessTapController` uses `nonisolated(unsafe)` atomic properties for all state accessed from the audio callback thread: volume, mute, peak levels, EQ parameters, diagnostic counters. No locks, no allocations on the RT path.

### Tap Health & Diagnostics
`AudioEngine` runs a 3-second health check timer. `TapDiagnostics` captures 19 RT-safe counters per tap (callback counts, silence flags, converter stats, peak levels, format info). Health checks detect both stalled taps (callbacks stopped) and broken taps (callbacks running but input disconnected).

### coreaudiod Restart Recovery
`AudioEngine` listens for `kAudioHardwarePropertyServiceRestarted`. On daemon restart, it destroys all stale taps, waits 1.5s for stabilization, then recreates all taps via `applyPersistedSettings()`.

### Design System
`DesignTokens` centralizes all magic numbers: 13 color categories, 6 typography styles, 7 spacing values, 15 dimension groups, scroll thresholds, animation curves, and timing constants.

### Shared Utilities
- `SliderAutoUnmute` — ViewModifier replacing duplicated auto-unmute-on-drag in AppRow/DeviceRow
- `DeviceIconView` — NSImage display with SF Symbol fallback, used by DeviceRow/DevicePicker
- `CoreAudioQueues` — shared `DispatchQueue` factory for CoreAudio listener callbacks
- `AudioObjectID+Listener` — add/remove listener factory used by 3 monitors

## File Layout

```
FineTune/
├── FineTuneApp.swift                          App entry + AppDelegate
├── Audio/
│   ├── AudioEngine.swift                      Main orchestrator
│   ├── AudioDeviceMonitor.swift               Device discovery
│   ├── AudioProcessMonitor.swift              App audio detection
│   ├── DeviceVolumeMonitor.swift              Volume/mute tracking
│   ├── ProcessTapController.swift             Per-app audio tap
│   ├── EQProcessor.swift                      10-band EQ
│   ├── BiquadMath.swift                       Biquad filter math
│   ├── Crossfade/
│   │   └── CrossfadeState.swift               Lock-free crossfade FSM
│   ├── Processing/
│   │   ├── AudioBufferProcessor.swift
│   │   ├── AudioFormatConverter.swift
│   │   ├── GainProcessor.swift
│   │   ├── SoftLimiter.swift
│   │   └── VolumeRamper.swift
│   ├── Tap/
│   │   ├── TapDiagnostics.swift               RT-safe diagnostic snapshot
│   │   └── TapResources.swift                 CoreAudio resource lifecycle
│   ├── Types/
│   │   ├── AudioScope.swift
│   │   ├── CoreAudioQueues.swift              Shared listener queue
│   │   ├── TapFormat.swift
│   │   └── TransportType.swift
│   └── Extensions/                            CoreAudio property access (9 files)
├── Models/
│   ├── AudioApp.swift
│   ├── AudioDevice.swift
│   ├── EQPreset.swift
│   ├── EQSettings.swift
│   ├── VolumeMapping.swift
│   └── VolumeState.swift
├── Settings/
│   └── SettingsManager.swift
├── Utilities/
│   ├── DeviceIconCache.swift
│   └── SingleInstanceGuard.swift
└── Views/
    ├── MenuBarPopupView.swift                 Main popup UI
    ├── MenuBarPopupViewModel.swift            Presentation logic
    ├── DevicePickerView.swift
    ├── EQPanelView.swift
    ├── EQSliderView.swift
    ├── MenuBar/
    │   └── MenuBarStatusController.swift      NSStatusItem + panel lifecycle
    ├── Rows/
    │   ├── AppRow.swift
    │   ├── AppRowWithLevelPolling.swift
    │   ├── AppRowEQToggle.swift               Animated EQ toggle button
    │   └── DeviceRow.swift
    ├── Components/
    │   ├── DeviceIconView.swift               Shared icon component
    │   ├── DevicePicker.swift
    │   ├── DropdownMenu.swift
    │   ├── EQPresetPicker.swift
    │   ├── ExpandableGlassRow.swift
    │   ├── LiquidGlassSlider.swift
    │   ├── MouseInsideModifier.swift
    │   ├── MuteButton.swift
    │   ├── PopoverHost.swift
    │   ├── RadioButton.swift
    │   ├── SectionHeader.swift
    │   ├── SliderAutoUnmute.swift             Auto-unmute ViewModifier
    │   └── VUMeter.swift
    ├── DesignSystem/
    │   ├── DesignTokens.swift                 Centralized design tokens
    │   ├── ViewModifiers.swift
    │   └── VisualEffectBackground.swift
    └── Previews/
        ├── MockData.swift
        └── PreviewContainer.swift

testing/tests/                                 220 tests (~1.1s)
├── AudioBufferTestHelpers.swift               Shared test helpers
├── IntegrationTestHelpers.swift
├── AppRowInteractionTests.swift               20 UI interaction tests
├── AudioEngineCharacterizationTests.swift     7 characterization tests
├── ProcessTapControllerTests.swift            15 characterization tests
├── AudioEngineRoutingTests.swift              Integration tests
├── AudioSwitchingTests.swift
├── DefaultDeviceBehaviorTests.swift
├── StartupAudioInterruptionTests.swift
├── SingleInstanceGuardTests.swift
├── BiquadMathTests.swift                      Unit tests
├── CrossfadeStateTests.swift
├── EQPresetTests.swift
├── EQSettingsTests.swift
├── GainProcessorTests.swift
├── AudioBufferProcessorTests.swift
├── SoftLimiterTests.swift
├── VolumeMappingTests.swift
└── VolumeRamperTests.swift
```
